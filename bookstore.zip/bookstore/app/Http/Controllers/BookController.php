<?php namespace App\Http\Controllers;

use App\Book;
use App\Http\Requests;
use App\Http\Requests\BookRequest;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
//use Request;

class BookController extends Controller {

	/**
	 * Display a listing of the resource.
	 *
	 * @return Response
	 */
	public function index()
	{
		$books=Book::all();
        return view('books.home',compact('books'));
	}

	/**
	 * Show the form for creating a new resource.
	 *
	 * @return Response
	 */

	public function create()
	{
		return view('books.create');
	}
	
	/**
	 * Store a newly created resource in storage.
	 *
	 * @return Response
	 */
	 
public function store(Request $request)
	{
		$book=$request->all(); // important!!
	   Book::create($book);
	   return redirect('books');
	}
	
	
	/**
	 * Display the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function show($id)
	{
		//
		$book=Book::find($id);
   return view('books.show',compact('book'));
	}

	/**
	 * Show the form for editing the specified resource.
	 *
	 * @param  int  $id
	 * @return Response
	 */
	public function edit($id)
	{
		//
		 $book=Book::find($id);
   		return view('books.edit',compact('book'));
	}


	public function update($id, Request $request)
	{
	  $book=Book::find($id);
	  $book->update($request->all());
   
   	return redirect('books');
	}
	
	
	
	public function destroy($id)
	{
		//
		 Book::find($id)->delete();
   		return redirect('books');
	}

}
